# Node Tutorial

* 노드란 무엇인가 (javaScript) ddjango
* express.js는 무엇인가 
* 서버가 하는 역할
* API란 무엇인가
* CRUD - creat read update delete - db언어
* POST GET DELETE PUT PATCH - html 언어들

let abcd = [] - arry
let abcd = {}
